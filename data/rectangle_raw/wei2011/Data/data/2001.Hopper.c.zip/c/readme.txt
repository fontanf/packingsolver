Description:
This file contains 21 test problems used in Hopper and Turton (2000). All problems are regular. The problem size lies between 16 to 197 items. 
These data are also published in the OR-Library
(Data sets: c1, c2, ..., c7)

References: 
Hopper, E.; Turton, B.C.H., An Empirical Investigation of Meta-heuristic and Heuristic Algorithms for a 2D Packing Problem, 
European Journal of Operational Research 128/1, 34-57 